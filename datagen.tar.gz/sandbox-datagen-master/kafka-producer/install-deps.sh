#!/bin/bash
sudo pip install --upgrade pip
sudo pip install kafka faker

sudo chmod -R 777 /usr/lib/python2.7/site-packages/kafka
sudo chmod -R 777 /usr/lib/python2.7/site-packages/kafka/kafka-1.3.5.dist-info
sudo chmod -R 777 /usr/lib/python2.7/site-packages/text_unidecode*
sudo chmod -R 777 /usr/lib/python2.7/site-packages/dateutil
