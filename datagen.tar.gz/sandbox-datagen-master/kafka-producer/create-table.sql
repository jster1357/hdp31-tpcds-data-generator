create database if not exists kafka;

create external table kafka.kafka_demo_pos_events
(
store_id int,
part_sku string,
rep_id int,
qty int,
cust_id int,
discount_amt double,
trxn_amt double,
trxn_time timestamp
)
stored by 'org.apache.hadoop.hive.kafka.KafkaStorageHandler'
TBLPROPERTIES(
"kafka.topic" = "demo",
"kafka.bootstrap.servers"="${KAFKASERVER}")

